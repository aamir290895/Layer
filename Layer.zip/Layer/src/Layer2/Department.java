package Layer2;

public class Department {

	private int departmentNumber;
	private String departmentName;
	private String departmentLocation;
	public Department() 
	{
	  System.out.println(" Department Info :" );	
	}
	
	public int getDepartmentNumber(int departmentNumber) {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLocation() {
		return departmentLocation;
	}
	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
	
	
}
