package Layer4;

import java.util.List;

import Layer2.Department;
import Layer3.DeparmentDAOImpl;

public class DepartmentServiceImpl implements DepartmentService {
    DeparmentDAOImpl  depDao = new DeparmentDAOImpl();
	@Override
	public void createDepartmentService(Department dobj) {
		
		depDao.inserDepartment(dobj);
		System.out.println("DepartmentServiceImpl :start");
		System.out.println("DepartmentServiceImpl : createDepartment");

		System.out.println("DepartmentServiceImpl : finish");

		// TODO Auto-generated method stub

	}
	@Override
	public List<Department> findAllDepartmentService() {
		// TODO Auto-generated method stub
		return depDao.selectDepartments();
	}
	

}
