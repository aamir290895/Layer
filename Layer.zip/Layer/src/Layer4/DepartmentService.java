package Layer4;

import java.util.List;

import Layer2.Department;

public interface DepartmentService {
	void createDepartmentService(Department obj);
	List<Department> findAllDepartmentService();

}
