package Layer3;

import java.util.List;

import Layer2.Department;

public interface DepartmentDAO {
	
     void inserDepartment(Department obj);
	 
	 Department selectDepartment(int dno);
	 List <Department> selectDepartments();
	 void updateDepartment(Department obj);
	 void deleteDepartment(Department dobj);

		
	

}
