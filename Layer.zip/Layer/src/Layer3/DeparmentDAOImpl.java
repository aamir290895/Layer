package Layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Layer2.Department;

public class DeparmentDAOImpl implements DepartmentDAO {
	
	Connection connection;
	
public  DeparmentDAOImpl() {
	
	try {
		  DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
		  connection = DriverManager.getConnection(
					"jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
				 System.out.println("Connected...."+connection);
				 
		
		  
		  
	}catch(SQLException e) {
		e.printStackTrace();
		
		
	}
	
}

	

	@Override
	public void inserDepartment(Department obj) {
		System.out.println("insertDepatment:" + obj);
		try {
			PreparedStatement pst = connection.prepareStatement("insert into dept values(?,?,?,?)");
			pst.setInt(1, obj.getDepartmentNumber(0));
			pst.setString(2, obj.getDepartmentName());
			pst.setString(2, obj.getDepartmentLocation());
			int rows = pst.executeUpdate();
			
			
			pst.close();
			connection.close();

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}

	@Override
	public Department selectDepartment(int dno) {
		// TODO Auto-generated method stub
		System.out.println("DepartmentDAOImpl : Selecting department");

		return null;
	}

	@Override
	public List<Department> selectDepartments() {
		List<Department> depList = new ArrayList<Department>();
		
		try {
			 		 
			  Statement st = connection.createStatement();
			  ResultSet rs = st.executeQuery("select*from dept");
			  while(rs.next()) {
				  Department dept = new Department();
				  dept.setDepartmentNumber(rs.getInt(1));
				  dept.setDepartmentName(rs.getString(2));
				  dept.setDepartmentLocation(rs.getString(3));
				  depList.add(dept);
			  }
			  
		}catch(SQLException e) {
			e.printStackTrace();
			
			
		}
		// TODO Auto-generated method stub
		return depList;
	}

	@Override
	public void updateDepartment(Department obj) {
		// TODO Auto-generated method stub
		System.out.println("DepartmentDAOImpl : Updating department");

	}

	@Override
	public void deleteDepartment(Department dobj) {
		// TODO Auto-generated method stub
		System.out.println("DepartmentDAOImpl : Deleting department");

	}

}
