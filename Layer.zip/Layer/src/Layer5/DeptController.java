package Layer5;

import java.util.List;

import Layer2.Department;
import Layer4.DepartmentServiceImpl;

public class DeptController {
	
	
	public static void main(String[] args) {
		DepartmentServiceImpl depService = new DepartmentServiceImpl();
		int i = 55;
		Department depObject = new Department();
		depObject.setDepartmentLocation("hotel");
		depObject.setDepartmentName("Food");
		depObject.getDepartmentNumber(i);
		
		depService.createDepartmentService(depObject);
		System.out.println(depObject);
		
		List<Department> depList = depService.findAllDepartmentService();
		for (Department theDept : depList) {
			System.out.println("Dep No :" + theDept.getDepartmentNumber(1));
			System.out.println("Dep Name :" + theDept.getDepartmentName());
			System.out.println("Dep Location :" + theDept.getDepartmentLocation());

		}
	}

}
